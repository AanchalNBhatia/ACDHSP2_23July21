import { LightningElement, track, wire } from 'lwc';
import stepProgressCss from '@salesforce/resourceUrl/stepProgressCss';
import { loadStyle } from 'lightning/platformResourceLoader';
import user_Id from '@salesforce/user/Id';
import getUserDetails from '@salesforce/apex/SPPortalContainerCntrl.getUserDetails';
import getIRTSettings from '@salesforce/apex/IRT_LWC_Cntrl.getIRTSettings';
import createReferral from '@salesforce/apex/IRT_LWC_Cntrl.createReferral';
import portalURL from '@salesforce/label/c.Portal_URL';
import acdhs_accId from '@salesforce/label/c.ACDHS';

export default class Irt_Container extends LightningElement {
    error;
    progressStyle = stepProgressCss;
    @track steps = [
        {
            Order : 1,
            Name : "Referral Form",
            Class: "active"
        },
        {
            Order : 2,
            Name : "Select Primary Reason",
            Class: ""
        },
        {
            Order : 3,
            Name : "Select Concerns",
            Class: ""
        },
        {
            Order : 4,
            Name : "Confirmation",
            Class: ""
        }
    ];
    userId = user_Id;
    showQuestionnaire = false;
    accId; conId; userLic = ''; profileName;
    showReferralForm = true; showPrimaryReason = false; showConcerns = false; showConfirmation = false;
    selectedRefType = ''; selectedClientId = ''; @track referralFields = []; @track clientIds = []; backToRefForm = false;
    refFormFields;
    selectedPrimReasonId; selectedPrimReasonName;
    @track selectedConcerns = [];
    refURL; refNumber; showSuccess = false;

    constructor () {
        super();
        Promise.all([loadStyle(this, this.progressStyle)]);
    }

    @wire(getUserDetails, { userId: '$userId'})
    wiredUserDetails (result) {
        if (result.data)
        {
            console.log('#### User data: ' + JSON.stringify(result.data));
            //this.userLic = result.data.Profile.UserLicense.Name;
            this.profileName = result.data.Profile.Name;
            if (this.profileName.includes('Provider')) //Provider User
            {
                this.accId = result.data.Contact.Account.Id;
                this.conId = result.data.ContactId;
            }
            else //ACDHS User
            {
                this.accId = acdhs_accId;
                this.conId = result.data.Contact_Id__c;
            }

            /* if (result.data.Contact != undefined && result.data.Contact != null) //Provider User
            {
                this.accId = result.data.Contact.Account.Id;
                this.conId = result.data.ContactId;
            }
            else //ACDHS User
            {
                this.accId = result.data.AccountId;//acdhs_accId;
                this.conId = result.data.Id;
            } */
        }
        else if (result.error)
        {
            this.error = result.error;
            console.log('#### error wiredUserDetails: ' + JSON.stringify(result.error));
        }
    }

    @wire(getIRTSettings)
    wiredIRTSettings (result) {
        console.log('#### showQuestionnaire result: ' + JSON.stringify(result));
        if (result.data)
        {
            this.showQuestionnaire = result.data;
        }
        else if (result.error)
        {
            this.error = result.error;
            console.log('#### error showQuestionnaire: ' + JSON.stringify(result.error));
        }
    }

    handleReferralSubmit (event) {
        this.selectedRefType = event.detail.refType;
        this.selectedClientId = event.detail.clientId;
        this.referralFields = event.detail.referral;
        this.clientIds = event.detail.selectedHHM;
        console.log('#### selectedRefType: ' + this.selectedRefType);
        console.log('#### referralFields: ' + JSON.stringify(event.detail.referral));
        console.log('#### selectedHHM: ' + JSON.stringify(event.detail.selectedHHM));
        this.showPrimaryReason = true;
        this.showReferralForm = false;
        this.steps[0].Class = 'completed';
        this.steps[1].Class = 'active';
        this.refFormFields = {
            "reason" : event.detail.referral.Reason_for_Referral__c,
            "numberHHM" : event.detail.referral.Number_of_Household_Members__c,
            "incomeHH" : event.detail.referral.Household_Income__c,
            "rbFName" : event.detail.referral.RB_First_Name__c,
            "rbLName" : event.detail.referral.RB_Last_Name__c,
            "rbOrg" : event.detail.referral.RB_Organization__c,
            "rbMobile" : event.detail.referral.RB_Mobile__c,
            "rbEmail" : event.detail.referral.RB_Email__c,
            "rbSource" : event.detail.referral.RB_Source__c,
            "rbSelf" : event.detail.referral.Self_Referral__c,
            "refFormSSN" : event.detail.referral.SSN__c
        };
    }

    handleBackToRefForm () {
        console.log('#### In handleBackFromPrimReason');
        this.steps[0].Class = 'active';
        this.steps[1].Class = '';
        this.showPrimaryReason = false;
        this.showReferralForm = true;
        this.backToRefForm = true;
    }

    handlePrimReasonSelected (event) {
        this.selectedPrimReasonId = event.detail.primReasonId;
        this.selectedPrimReasonName = event.detail.primReasonName;
        console.log('#### selectedPrimReasonId: ' + this.selectedPrimReasonId);
        this.showPrimaryReason = false;
        this.showConcerns = true;
        this.steps[1].Class = 'completed';
        this.steps[2].Class = 'active';
    }

    handleBackToPrimReason () {
        console.log('#### In handleBackToPrimReason');
        this.steps[1].Class = 'active';
        this.steps[2].Class = '';
        this.showPrimaryReason = true;
        this.showConcerns = false;
    }

    handleConcernsSelected (event) {
        this.selectedConcerns = event.detail.selectedConcerns;
        console.log('#### selectedConcerns: ' + this.selectedConcerns);
        this.showConcerns = false;
        this.showConfirmation = true;
        this.steps[2].Class = 'completed';
        this.steps[3].Class = 'active';
        this.submitReferral();
    }

    submitReferral () {
        console.log('#### concerns selected: ' + this.selectedConcerns);
        console.log('#### clientIds before: ' + this.clientIds);
        console.log('#### selectedClientId: ' + this.selectedClientId);
        if (this.clientIds != undefined && this.clientIds != null) this.clientIds = [...this.clientIds, this.selectedClientId];
        else this.clientIds = [this.selectedClientId];
        console.log('#### clientIds after: ' + this.clientIds);
        console.log('#### clientIds: ' + JSON.stringify(this.clientIds));
        createReferral({referral: this.referralFields, primReasonId: this.selectedPrimReasonId, concerns: this.selectedConcerns, listClients: this.clientIds, refType: this.selectedRefType, selectedClientId: this.selectedClientId})
        .then((result) => {
            console.log('#### createReferral return: ' + JSON.stringify(result));
            if (result.status.includes('Error'))
            {}
            else
            {
                this.steps[3].Class = 'completed';
                this.showSuccess = true;
                this.refNumber = result.ref.Name;
                console.log('#### profile: ' + this.profileName);

                if (this.profileName == 'System Administrator' || this.profileName == 'Internal Super User') //ACDHS Admin or Super User
                {
                    this.refURL = '/' + result.ref.Id;
                }
                else //Portal User
                {
                    this.refURL = portalURL + '/detail/' + result.ref.Id;
                }
            }
        })
        .catch((error) => {
            this.error = error;
        });
    }
}