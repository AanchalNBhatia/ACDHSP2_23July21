import { LightningElement, wire, track, api } from 'lwc';
import getExistingHouseholds from '@salesforce/apex/HouseHoldMngmtController.getExistingHouseholds';
import getHHAcc from '@salesforce/apex/HouseHoldMngmtController.getHHAcc';
export default class ExistingHHMembers extends LightningElement {
    @api recordId='';
    priAccId='';
    isExistingHHEmpty = true;
    accDetWrapper =null;
    accName='';
    completeResult=[];
    @api masterList=[];
    @api existingList=[];
    selectedClientIds=[];
    firstLoad = true;
    connectedCallback(){
        getHHAcc({clientId: this.recordId, isDepMember: false})
        .then(result=>{
            this.accDetWrapper = result;
            this.accName = this.accDetWrapper.accountName;
            this.priAccId = this.accDetWrapper.accountId;
            console.log(this.priAccId,this.accName);
        })
        .catch(error =>{
            console.log(error)
        })
    }
    /*@wire(getHHAcc,{clientId: '$recordId'})
    wiredAccountDetails(result){
        if(result.data){
            console.log(result.data)
            this.accDetWrapper = result.data;
            this.accName = this.accDetWrapper.accountName;
            this.priAccId = this.accDetWrapper.accountId;
            console.log('priAccId....'+ this.priAccId);
        }
        else if(result.error){
            console.log(result.error)
        }
    }*/
        
    //getting the existing record from sf
    @wire(getExistingHouseholds, { clientId: '$recordId', accId: '$priAccId' })
    wiredWrapperData(result) {
        this.completeResult = result;
        if (result.data) {
            this.masterList = result.data;
            if(this.masterList.length > 0)
            {
                
                this.existingList =JSON.parse(JSON.stringify(this.masterList));
                console.log(this.existingList)
                this.isExistingHHEmpty = false;
                if(this.firstLoad){
                    //send existing list to the parent
                    const selectedEvent = new CustomEvent("existingloaded", {
                        detail: this.existingList
                    });
                    // Dispatches the event.
                    this.dispatchEvent(selectedEvent);
                    this.firstLoad = false;
                }
                
            }            
            else{
                this.isExistingHHEmpty = true;
            }
        }
        else if (result.error) {
            this.error = result.error;
            this.isExistingHHEmpty = true;
        }
    }

    //columns to display using lightning data table
    columns = [
        {
            label: 'Name', fieldName: 'url', type: 'url', wrapText: true, typeAttributes: {
                label: { fieldName: 'name' },
                target: '_blank'
            }
        },
        { label: 'Category', fieldName: 'category', type: 'text', wrapText: true },
        { label: 'Relationship', fieldName: 'relation', type: 'text', wrapText: true },
        { label: 'Gender', fieldName: 'gender', type: 'text', wrapText: true },
        { label: 'Direct', fieldName: 'isDirect', type: 'boolean', wrapText: true },
    ]

    //code to be executed on click og toggle
    handleToggle(event){
        var isChecked = event.detail.checked;
        if(isChecked){
            this.existingList = this.existingList.filter(item =>{
                return item.isDirect == true
            })
        }
        else{
            this.existingList =JSON.parse(JSON.stringify(this.masterList)) ;
        }
        console.log(this.existingList);
    }
    //on selecting a row
    handleRowSelection(event){
        const selectedRows = event.detail.selectedRows;
        this.selectedClientIds = [];
        for (let i = 0; i < selectedRows.length; i++) {
            this.selectedClientIds.push(selectedRows[i].priConId);
        }
        const selectedEvent = new CustomEvent("clientselected", {
            detail: this.selectedClientIds
        });
        // Dispatches the event.
        this.dispatchEvent(selectedEvent);
    }
    @api addToList(member){
        this.existingList = [...this.existingList, JSON.parse(JSON.stringify(member))]
        this.masterList = [...this.masterList, JSON.parse(JSON.stringify(member))]
        console.log(this.existingList);
        this.isExistingHHEmpty = false;
    }
}