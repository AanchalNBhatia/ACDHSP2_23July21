import { LightningElement, wire, api, track } from 'lwc';
import { getRecord, getFieldValue, getFieldDisplayValue } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

//const conFields = ['Contact.AccountId', 'Contact.FirstName', 'Contact.LastName', 'Contact.Birthdate', 'Contact.Gender__c', 'Contact.SSN__c', 'Contact.Phone', 'Contact.Email', 'Contact.MailingStreet', 'Contact.MailingCity', 'Contact.MailingState', 'Contact.County__c', 'Contact.MailingPostalCode'];
const clientFields = ['Client__c.First_Name__c', 'Client__c.Last_Name__c', 'Client__c.Chosen_Name__c', 'Client__c.Date_of_Birth__c', 'Client__c.Legal_Sex__c', 'Client__c.SSN__c', 'Client__c.Address_Type__c', 'Client__c.Street_Address_1__c', 'Client__c.Street_Address_2__c', 'Client__c.City__c', 'Client__c.County__c', 'Client__c.State__c', 'Client__c.Zip_Code__c', 'Client__c.Phone_Type__c', 'Client__c.Phone_Number__c', 'Client__c.Email__c', 'Client__c.Pronouns__c', 'Client__c.MCI_ID__c', 'Client__c.Client_Create_MCI__c'];

export default class Irt_ReferralForm extends LightningElement {
    isLoading = false;
    error;
    get optionsRefType() {
        return [
            { label: 'Individual', value: 'Individual' },
            { label: 'Individual within a Household', value: 'Individual within a Household' },
            { label: 'Household', value: 'Household' }
        ];
    }
    showTypeSelection = true; showInd = false; showHH = false; showIndHH = false; disableNext = true; disableBack = true;
    refDateVal; fNameVal; cNameVal; lNameVal; pronounVal; dobVal; approxAgeVal; legalSexVal; ssnVal; addTypeVal; stAdd1Val; stAdd2Val; cityVal; countyVal; stateVal; zipVal; phoneTypeVal; phoneVal; emailVal; mciVal; refReasonVal; hhMemVal; hhIncomeVal; rbFNameVal; rbLNameVal; rbOrgVal; rbMobileVal; rbEmailVal; rbSourceNameVal; rbSelfVal; confVal; ssnFormVal;
    @api clientId = ''; @api selectedRefType; @api fromBack = false; @api refFormFields;
    @track existingHHMList = [];
    openAddHHModal = false;
    @track primRefFields = [];
    @track selectedHHM;
    mciCleared = false; showMCITable = false;
    initialRender = true;
    referredByDisable = false; renderRefBy = true;
    renderHHMval = true; renderHHIncomeval = true;
    renderSSNval = true

    renderedCallback () {
        console.log('#### In rencall');
        if (this.initialRender)
        {
            console.log('#### this.selectedRefType: ' + this.selectedRefType);
            if ((this.selectedRefType != null && this.selectedRefType != '' && this.selectedRefType != undefined) && this.fromBack == true)
            {
                //this.isLoading = true;
                this.showTypeSelection = false;
                if (this.selectedRefType == 'Individual') this.showInd = true;
                if (this.selectedRefType == 'Household') this.showHH = true;
                if (this.selectedRefType == 'Individual within a Household') 
                {
                    this.showIndHH = true;
                    this.showInd = true;
                }
                this.disableBack = false;
                this.disableNext = false;
            }

            if (this.refFormFields != null && this.refFormFields != '')
            {
                this.refReasonVal = this.refFormFields.reason;
                this.hhMemVal = this.refFormFields.numberHHM;
                this.hhIncomeVal = this.refFormFields.incomeHH;
                this.rbFNameVal = this.refFormFields.rbFName;
                this.rbLNameVal = this.refFormFields.rbLName;
                this.rbOrgVal = this.refFormFields.rbOrg;
                this.rbMobileVal = this.refFormFields.rbMobile;
                this.rbEmailVal = this.refFormFields.rbEmail;
                this.rbSourceNameVal = this.refFormFields.rbSource;
                this.rbSelfVal = this.refFormFields.rbSelf;
                if (this.refFormFields.refFormSSN != null && this.refFormFields.refFormSSN != '')
                {
                    this.formatSSN(this.refFormFields.refFormSSN);
                }
            }
        }
        if (this.refFormFields != null && this.refFormFields != '')
        {
            if (this.refFormFields.refFormSSN != null && this.refFormFields.refFormSSN != '')
            {
                this.formatSSN(this.refFormFields.refFormSSN);
            }
        }
        console.log('#### Rencall Over');
    }

    handleRefTypeChange (event) {
        this.isLoading = true;
        console.log('#### sel: ' + event.detail.value);
        this.showTypeSelection = false;
        if (event.detail.value == 'Individual') this.showInd = true;
        if (event.detail.value == 'Household')
        {
            this.showIndHH = true;
            this.showInd = true;
            this.showHH = true;
        }
        if (event.detail.value == 'Individual within a Household') 
        {
            this.showIndHH = true;
            this.showInd = true;
        }
        this.selectedRefType = event.detail.value;
        this.disableBack = false;
    }

    handleBack () {
        this.showTypeSelection = true;
        this.showInd = false;
        this.showHH = false;
        this.showIndHH = false;
        this.disableBack = true;
        this.disableNext = true;
        this.selectedRefType = null;
        this.clientId = '';
        this.clearFormValues();
    }

    clearFormValues () {
        this.fNameVal = null; this.lNameVal = null; this.cNameVal = null; this.dobVal = null; this.approxAgeVal = null; this.legalSexVal = null; this.addTypeVal = null; this.stAdd1Val = null; this.stAdd2Val = null; this.cityVal = null; this.countyVal = null; this.stateVal = null; this.zipVal = null; this.phoneTypeVal = null; this.phoneVal = null; this.emailVal = null; this.template.querySelector('.ssn').value = null; this.refReasonVal = null; this.hhMemVal = null; this.hhIncomeVal = null; this.rbFNameVal = null; this.rbLNameVal = null; this.rbOrgVal = null; this.rbMobileVal = null; this.rbEmailVal = null; this.rbSourceNameVal = null; this.rbSelfVal = null; this.refFormFields = null; this.confVal = null; this.pronounVal = null; this.mciVal = null; this.ssnFormVal = null;
    }

    handleFormLoad () {
        this.isLoading = false;
    }

    handleClientChange (event) {
        console.log('#### Client Con ID: ' + event.detail.value[0]);
        if (event.detail.value[0] == undefined || event.detail.value[0] == null)
        {
            this.disableNext = true;
            this.clientId = null;
            this.clearFormValues();
        }
        else
        {
            this.clientId = event.detail.value[0];
            this.disableNext = false;
        }
    }

    @wire(getRecord, { recordId: '$clientId', fields: clientFields })
    wiredContactData (result) {
        if (result.data)
        {
            //console.log('#### client: ' + JSON.stringify(result.data));
            //console.log('#### FName: ' + getFieldValue(result.data, 'Client__c.FirstName'));
            this.fNameVal = getFieldValue(result.data, 'Client__c.First_Name__c');
            this.cNameVal = getFieldValue(result.data, 'Client__c.Chosen_Name__c');
            this.lNameVal = getFieldValue(result.data, 'Client__c.Last_Name__c');
            this.pronounVal = getFieldValue(result.data, 'Client__c.Pronouns__c');
            this.dobVal = getFieldValue(result.data, 'Client__c.Date_of_Birth__c');
            if (this.dobVal != null && this.dobVal != undefined)
            {
                this.calculateApproxAge(this.dobVal);
            }
            this.legalSexVal = getFieldDisplayValue(result.data, 'Client__c.Legal_Sex__c');
            this.addTypeVal = getFieldValue(result.data, 'Client__c.Address_Type__c');
            this.stAdd1Val = getFieldValue(result.data, 'Client__c.Street_Address_1__c');
            this.stAdd2Val = getFieldValue(result.data, 'Client__c.Street_Address_2__c');
            this.cityVal = getFieldValue(result.data, 'Client__c.City__c');
            this.countyVal = getFieldValue(result.data, 'Client__c.County__c');
            this.stateVal = getFieldValue(result.data, 'Client__c.State__c');
            this.zipVal = getFieldValue(result.data, 'Client__c.Zip_Code__c');
            this.phoneTypeVal = getFieldValue(result.data, 'Client__c.Phone_Type__c');
            this.phoneVal = getFieldValue(result.data, 'Client__c.Phone_Number__c');
            this.emailVal = getFieldValue(result.data, 'Client__c.Email__c');
            this.mciVal = getFieldValue(result.data, 'Client__c.MCI_ID__c');
            this.mciCleared = (this.mciVal != null && this.mciVal != '') ? true : false;
            var ssn = getFieldValue(result.data, 'Client__c.SSN__c');
            console.log('#### ssn: ' + ssn);
            if (ssn != null && ssn != '')
            {
                this.formatSSN(getFieldValue(result.data, 'Client__c.SSN__c'));
                this.ssnVal = getFieldValue(result.data, 'Client__c.SSN__c');
            }
            this.initialRender = false;

            if (getFieldValue(result.data, 'Client__c.Client_Create_MCI__c') == false)
            {
                this.showMCITable = true;
            }
        }
        else if (result.error)
        {
            this.error = result.error;
            console.log('#### error: ' + JSON.stringify(result.error));
            this.initialRender = false;
        }
    }

    dobChange (event)
    {
        console.log('#### dobChange: ' + event.detail.value);
        var enteredDate = new Date(event.detail.value);
        var now = new Date();
        if (enteredDate > now)
        {
            this.dobVal = now;
            const event = new ShowToastEvent({
                title: 'Error!',
                message: 'Date of Birth cannot be greater than Today!',
                variant: 'error'
            });
            this.dispatchEvent(event);
        }
        else
        {
            if (event.detail.value != null && event.detail.value != undefined) this.calculateApproxAge(event.detail.value);
            else this.approxAgeVal = null;
        }
    }

    calculateApproxAge (dob1) {
        console.log('#### dob1: ' + dob1);
        var dob = new Date(dob1);
        var diff_ms = Date.now() - dob.getTime();
        var age_dt = new Date(diff_ms);
        var age = Math.abs(age_dt.getUTCFullYear() - 1970);
        console.log('#### age: ' + age);
        this.approxAgeVal = age;
    }

    formatSSN (ssnValue) {
        var sizes = [3, 2, 4];
        var newVal = '';
        var refSSN = '';
        for (var i in sizes) 
        {
            if (ssnValue.length > sizes[i]) 
            {
                newVal += ssnValue.substr(0, sizes[i]) + '-';
                refSSN += ssnValue.substr(0, sizes[i]) + '-';
                ssnValue = ssnValue.substr(sizes[i]);
            }
        }
        refSSN += ssnValue;
        newVal = 'XXX-XX-' + ssnValue;
        console.log('#### newVal: ' + newVal);
        //console.log('#### refSSN: ' + refSSN);
        if (this.template.querySelector('.ssn') != null) this.template.querySelector('.ssn').value = newVal;
    }

    startFormatSSN () {
        var input = this.template.querySelector('.ssn');
        if (input.validity.valid)
        {
            console.log('#### Valid: ' + this.template.querySelector('.ssn').value);
            if (this.isNumeric(this.template.querySelector('.ssn').value))
            {
                this.ssnVal = this.template.querySelector('.ssn').value;
                this.ssnRef = this.template.querySelector('.ssn').value;
                var val = this.template.querySelector('.ssn').value.replace(/\D/g, '');
                if (val != null && val != '')
                {
                    this.formatSSN(val);
                }
            }
            else
            {
                alert('Please enter only numeric values in SSN.');
                this.ssnVal = null;
                this.ssnRef = null;
                this.ssnFormVal = null;
                this.renderSSNval = false;
                setTimeout(() => {this.renderSSNval = true}, 0);
            }
        }
    }

    isNumeric(str) {
        if (typeof str != "string") return false // we only process strings!  
        return !isNaN(str) && // use type coercion to parse the _entirety_ of the string (`parseFloat` alone does not do this)...
               !isNaN(parseFloat(str)) // ...and ensure strings of whitespace fail
      }

    handleFormSubmit (event) {
        console.log('Next');
        event.preventDefault();
        const fields = event.detail.fields;
        fields.SSN__c = this.ssnVal;
        if (this.showInd || this.showIndHH)
        {
            console.log('#### ed string: ' + JSON.stringify(fields));
            this.primRefFields = fields;
            this.handleDispatchRefData();
        }
    }

    handleFormSuccess () {}

    handleFormError () {}

    handleDispatchRefData () {
        let refDataObj = {refType: this.selectedRefType, clientId: this.clientId, referral: this.primRefFields, selectedHHM: this.selectedHHM};
        const successEvent = new CustomEvent('submitsuccess', {detail : refDataObj});
        this.dispatchEvent(successEvent);
    }

    handleExistingHHMLoad (event) {
        console.log('#### handleExistingHHMLoad: ' + JSON.stringify(event.detail));
        this.existingHHMList = JSON.parse(JSON.stringify(event.detail));
    }

    handleAddNewHHMember () {
        this.openAddHHModal = true;
    }

    closeModal () {
        this.openAddHHModal = false;
    }

    handleSelectedHHM (event) {
        this.selectedHHM = event.detail;
        console.log('#### handleSelectedHHM: ' + this.selectedHHM);
    }

    handleNewHHMember (event) {
        this.template.querySelector('c-existing-h-h-members').addToList(event.detail);
    }

    handleRefDateChange (event) {
        console.log('#### date: ' + event.detail.value);
        var enteredDate = new Date(event.detail.value);
        var now = new Date();
        if (enteredDate > now)
        {
            this.refDateVal = now;
            const event = new ShowToastEvent({
                title: 'Error!',
                message: 'Referral Date cannot be greater than Today!',
                variant: 'error'
            });
            this.dispatchEvent(event);
        }
    }

    handleGetMciID () {
        this.showMCITable = true;
    }

    closeMCITable () {
        this.showMCITable = false;
    }

    handleSelfRefChange (event) {
        this.referredByDisable = event.target.value ? true : false;
        this.renderRefBy = false;
        setTimeout(() => {this.renderRefBy = true}, 0);
    }

    hhmValChange (event) {
        if (event.target.value < 0 || event.target.value > 999)
        {
            alert('Number of Household Members should be between 0-999.');
            this.renderHHMval = false;
            setTimeout(() => {this.renderHHMval = true}, 0);
        }
    }

    hhIncomeValChange (event) {
        if (event.target.value < 0 || event.target.value > 9999999999999999.99)
        {
            alert('Number of Household Income should be between 0-9,999,999,999,999,999.99');
            this.renderHHIncomeval = false;
            setTimeout(() => {this.renderHHIncomeval = true}, 0);
        }
    }
}