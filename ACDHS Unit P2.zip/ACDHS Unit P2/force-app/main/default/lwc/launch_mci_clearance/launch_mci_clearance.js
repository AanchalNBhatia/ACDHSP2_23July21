import { LightningElement, api, wire } from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';

const clientFields = ['Client__c.First_Name__c', 'Client__c.Last_Name__c', 'Client__c.Date_of_Birth__c', 'Client__c.Legal_Sex__c', 'Client__c.SSN__c', 'Client__c.CreatedDate', 'Client__c.LastModifiedDate', 'Client__c.MCI_ID__c', 'Client__c.Client_Create_MCI__c'];

export default class Launch_mci_clearance extends LightningElement {
    error;
    @api recordId;
    @api openModal = false;
    @api source;
    fromHHCmp = false;

    @wire(getRecord, { recordId: '$recordId', fields: clientFields })
    wiredClientData (result) {
        if (result.data)
        {
            console.log('#### cd: ' + getFieldValue(result.data, 'Client__c.CreatedDate'));
            console.log('#### Client_Create_MCI__c: ' + getFieldValue(result.data, 'Client__c.Client_Create_MCI__c'));
            var cd = new Date(getFieldValue(result.data, 'Client__c.CreatedDate'));
            var diffDate = Date.now() - cd.getTime();
            console.log('#### diffDate: ' + diffDate);
            /* if (diffDate < 15000)//5000 //Didnt work for some users. Would have been easier solution.
            {
                this.openModal = true;
            } */
            if (getFieldValue(result.data, 'Client__c.Client_Create_MCI__c') == false) this.openModal = true;
            if (this.source == 'hhCmp') this.fromHHCmp = true;
        }
        else if (result.error)
        {
            this.error = result.error;
            console.log('#### error: ' + JSON.stringify(result.error));
        }
    }

    closeModal () {
        this.openModal = false;
        if (this.source == 'IRT' || this.source == 'hhCmp')
        {
            const closeLwc = new CustomEvent('close');
            this.dispatchEvent(closeLwc);
        }
    }
}