import { LightningElement,api } from 'lwc';

export default class HHContainer extends LightningElement {
    @api recordId='';
    existingList=[];

    handleNewMember(event){
        this.template.querySelector('c-existing-h-h-members').addToList(event.detail)
    }
    populateExitsingList(event){
        this.existingList=[...this.existingList, JSON.parse(JSON.stringify(event.detail))];
    }
    handleSelectedClients(event){
        console.log(event.detail);
    }
}