import { LightningElement, api, wire } from 'lwc';
import Status_Field from '@salesforce/schema/Referral__c.Referral_Status__c';
import {  getRecord, getFieldValue, updateRecord } from 'lightning/uiRecordApi';
import USER_ID from '@salesforce/user/Id'; 
import searchUsersACDHSUsers from '@salesforce/apex/UserSearchController.searchUsersACDHSUsers';
import searchUsersPortalUsers from '@salesforce/apex/UserSearchController.searchUsersPortalUsers';
import Owner_Field from '@salesforce/schema/Referral__c.OwnerId';
import ID_FIELD from '@salesforce/schema/Referral__c.Id';
import { ShowToastEvent } from 'lightning/platformShowToastEvent'
import checkUserAccessOnReferral from '@salesforce/apex/DocCollectionCtrl.checkUserAccessOnReferral';
export default class AssignWorkerOnReferral extends LightningElement {
    @api recordId = '';
    refStatus = '';
    isError = false;
    loggedUserId = USER_ID;
    isACDHS = false;
    isPortal = false;
    selectedUserId = '';
    accountId='';
    isAccess = false;
    isAdminAccess = false;
    @wire (getRecord,{
        recordId:'$recordId',
        fields:[Status_Field]
    })
    wiredReferralResult(result){
        if(result.data){
            this.refStatus = getFieldValue(result.data, 'Referral__c.Referral_Status__c');
            console.log(this.refStatus);
            if(this.refStatus =='Not Accepted'){
                this.isNotAccepted = true;
                const event = new ShowToastEvent({
                    title: 'Error',
                    message: 'Sorry, Worker can\'t be assigned on Referral with status as \'Not Accepted\'',
                    variant: 'error'
                });
                this.dispatchEvent(event);
                const closeLwc = new CustomEvent('close');
                this.dispatchEvent(closeLwc);
            }
        }
        else if(result.error){
            console.log(result.error)
        }
    }
    @wire(checkUserAccessOnReferral,{UserId: '$loggedUserId', ReferralId: '$recordId'})
    wiredAccessibilityResult(result){
        if(result.data){
            console.log(result.data)
            let resultWrap = result.data;
            this.isAccess = resultWrap.isAccess;
            this.accountId = resultWrap.AccountId;
            this.isAdminAccess = resultWrap.isAdminAccess;
            if(this.accountId == '' || this.accountId == undefined || this.accountId == null){
                console.log('If sets acdhs true')
                this.isACDHS = true;
                this.isPortal = false;
            }
            if(this.isAdminAccess){
                this.isACDHS = true;
                this.isPortal = false;
            }
            else{
                console.log('If sets acdhs false')
                this.isACDHS = false;
                this.isPortal = true;
            }

            if(!this.isAccess && !this.isAdminAccess){
                const toastEve = new ShowToastEvent({
                    mode: "dismissable",
                    variant: "error",
                    title: "No Access",
                    message: "You don't have access to Assign Worker on this Referral"
                });
                this.dispatchEvent(toastEve);
                const closeLwc = new CustomEvent('close');
                this.dispatchEvent(closeLwc);
            }
        }
        else if(result.error){
            console.log(result.error)
        }
    }
    
    //Lookup code
    @api notifyViaAlerts = false;

    isMultiEntry = false;
    maxSelectionSize = 1;
    initialSelection = [];
    errors = [];
    recentlyViewed = [];
    /**
     * Handles the lookup search event.
     * Calls the server to perform the search and returns the resuls to the lookup.
     * @param {event} event `search` event emmitted by the lookup
     */
     handleLookupSearch(event) {
        const lookupElement = event.target;
        // Call Apex endpoint to search for records and pass results to the lookup
        if(this.isACDHS){
            console.log('in acdhs');
            if(this.isAdminAccess){
                console.log('in admin access')
                if(this.accountId != null && this.accountId != '' && this.accountId != undefined){
                    var argsJSON = JSON.parse(JSON.stringify(event.detail));
                    argsJSON["accId"] = this.accountId;
                    argsJSON = JSON.parse(JSON.stringify(argsJSON));
                    console.log(event.detail);
                    console.log(argsJSON);
                    searchUsersPortalUsers(argsJSON)
                    .then((results) => {
                        lookupElement.setSearchResults(results);
                    })
                    .catch((error) => {
                        this.notifyUser('Lookup Error', 'An error occured while searching with the lookup field.', 'error');
                        console.error('Lookup error', JSON.stringify(error));
                        this.errors = [error];
                    });
                }
                else{
                    searchUsersACDHSUsers(event.detail)
                    .then((results) => {
                        lookupElement.setSearchResults(results);
                    })
                    .catch((error) => {
                        this.notifyUser('Lookup Error', 'An error occured while searching with the lookup field.', 'error');
                        console.error('Lookup error', JSON.stringify(error));
                        this.errors = [error];
                    });
                }
            }
            else{
                searchUsersACDHSUsers(event.detail)
                .then((results) => {
                    lookupElement.setSearchResults(results);
                })
                .catch((error) => {
                    this.notifyUser('Lookup Error', 'An error occured while searching with the lookup field.', 'error');
                    console.error('Lookup error', JSON.stringify(error));
                    this.errors = [error];
                });
            }
        }
        else if(this.isPortal){
            console.log('inside isPortal');
            var argsJSON = JSON.parse(JSON.stringify(event.detail));
            argsJSON["accId"] = this.accountId;
            argsJSON = JSON.parse(JSON.stringify(argsJSON));
            console.log(event.detail);
            console.log(argsJSON);
            searchUsersPortalUsers(argsJSON)
            .then((results) => {
                lookupElement.setSearchResults(results);
            })
            .catch((error) => {
                this.notifyUser('Lookup Error', 'An error occured while searching with the lookup field.', 'error');
                console.error('Lookup error', JSON.stringify(error));
                this.errors = [error];
            });
        }
        
    }

    /**
     * Handles the lookup selection change
     * @param {event} event `selectionchange` event emmitted by the lookup.
     * The event contains the list of selected ids.
     */
    // eslint-disable-next-line no-unused-vars
    handleLookupSelectionChange(event) {
        this.checkForErrors();
    }

    // All functions below are part of the sample app form (not required by the lookup).

    handleLookupTypeChange(event) {
        this.initialSelection = [];
        this.errors = [];
        this.isMultiEntry = event.target.checked;
    }

    handleMaxSelectionSizeChange(event) {
        this.maxSelectionSize = event.target.value;
    }

    handleSubmit() {
        this.checkForErrors();
        if (this.errors.length === 0) {
            this.notifyUser('Success', 'The form was submitted.', 'success');
        }
    }

    handleClear() {
        this.initialSelection = [];
        this.errors = [];
    }

    checkForErrors() {
        this.errors = [];
        const selection = this.template.querySelector('c-lookup').getSelection();
        
        // Custom validation rule
        if (this.isMultiEntry && selection.length > this.maxSelectionSize) {
            this.errors.push({ message: `You may only select up to ${this.maxSelectionSize} items.` });
        }
        // Enforcing required field
        if (selection.length === 0) {
            this.errors.push({ message: 'Please make a selection.' });
        }
        console.log(selection[0].id);
        this.selectedUserId = selection[0].id;
        
    }

    notifyUser(title, message, variant) {
        if (this.notifyViaAlerts) {
            // Notify via alert
            // eslint-disable-next-line no-alert
            alert(`${title}\n${message}`);
        } else {
            // Notify via toast (only works in LEX)
            const toastEvent = new ShowToastEvent({ title, message, variant });
            this.dispatchEvent(toastEvent);
        }
    }
    handleSave(event){
        if(this.selectedUserId != null && this.selectedUserId != undefined && this.selectedUserId != ''){
            const fields = {};
            fields[ID_FIELD.fieldApiName] = this.recordId;
            fields[Owner_Field.fieldApiName] = this.selectedUserId;
            const recordInput = { fields };
            updateRecord(recordInput)
            .then(()=>{
                console.log('record updated')
                const closeLwc = new CustomEvent('close');
                // Dispatches the event.
                this.dispatchEvent(closeLwc);
            })
            .catch((error)=>{
                console.log(error)
                this.notifyUser('Error', 'Insufficient Access', 'error');
                this.errors = [error];
            })
        }
        
    }
    handleCancel(event){
        const closeLwc = new CustomEvent('close');
        // Dispatches the event.
        this.dispatchEvent(closeLwc);
    }
}