import { LightningElement, api, wire, track } from 'lwc';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import SP_SERVICE_OBJECT from '@salesforce/schema/SP_Service__c';
import CONCERNS_FIELD from '@salesforce/schema/SP_Service__c.Concerns__c';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class Irt_ConcernsSelection extends LightningElement {
    @api selectedPrimReasonId;
    value = [];
    @track selectedValues = [];

    @wire(getObjectInfo, { objectApiName: SP_SERVICE_OBJECT })
    spServiceMetadata;
    @track checkboxGroupData = [];

    @wire(getPicklistValues,{recordTypeId: '$spServiceMetadata.data.defaultRecordTypeId', fieldApiName: CONCERNS_FIELD})
    wiredPicklist({error, data}){
        if(data){
            if(data.values){
                data.values.forEach(concern => {
                    var temp = {};
                    temp.label = concern.label;
                    temp.value = concern.value;
                    this.checkboxGroupData.push(temp);
                });
                console.log("data # ",JSON.stringify(this.checkboxGroupData));
            }
        }
    }

    handleChange (event) {
        console.log(JSON.stringify(event.target.name));
        if(event.target.checked){
            if(this.selectedValues.indexOf(event.target.name) === -1){
                this.selectedValues.push(event.target.name);
            }
        }else{
            if(this.selectedValues.indexOf(event.target.name) !== -1){
                this.selectedValues = this.selectedValues.filter(function(val) {
                    return val !== event.target.name;
                })
            }
        }
        console.log("this.selectedValues # ", this.selectedValues);
    }

    handleSubmit () {
        console.log("Selected # ",JSON.stringify(this.selectedValues));
        if (this.selectedPrimReasonId == 'NoneID')
        {
            //return this.selectedValues;
            if (this.selectedValues.length === 0)
            {
                //alert("Please select at least one value");
                const event = new ShowToastEvent({
                    title: 'Please select at least one Concern',
                    message: 'Please select at least one Concern OR go back to the previous page and select 1 Primary Reason for the Referral.',
                    variant: 'error'
                });
                this.dispatchEvent(event);
            }
            else
            {
                this.handleSubmitToConfirm();
            }
        }
        else
        {
            this.handleSubmitToConfirm();
        }
    }

    handleBack () {
        const backtoprimreason = new CustomEvent('backtoprimreason');
        this.dispatchEvent(backtoprimreason);
    }

    handleSubmitToConfirm () {
        let concernsDataObj = {selectedConcerns: this.selectedValues};
        const concernsSelected = new CustomEvent('submitsuccess', {detail : concernsDataObj});
        this.dispatchEvent(concernsSelected);
    }
}