import { LightningElement,api,track,wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import checkUserAccess from '@salesforce/apex/CheckInteractionAccess.checkAccess';
import {getObjectInfo} from 'lightning/uiObjectInfoApi';
import Encounter_Obj from '@salesforce/schema/Encounter__c';
import userId from '@salesforce/user/Id';
import portalURL from '@salesforce/label/c.Portal_URL';
import getUserInfo from '@salesforce/apex/userDetails.getUserInfo';

export default class RecordInteractions extends LightningElement {
    error;
    startDateTime = '';
    stopDateTime = '';
    stopDisabled = true;
    createdEncounterId = '';
    @api recordId;
    @api objectApiName;
    hasAccess = false;
    renderCmp = true;
    recordTypeId = '';
    allRTInfo = {};
    @track selectedRTId = '';
    isSaveDisabled = false;
    uID=userId;
    pURL=portalURL;
    userProfile='';

    @wire (getUserInfo, {uId: '$uID'})
    wiredUserInfo (result) {
        if (result.data)
        {
            console.log('#### User Data: ' + JSON.stringify(result.data));
            this.userProfile=result.data.userProfile;
            console.log('#### uProfile: ' + this.userProfile);
            console.log('####URL: ' + this.pURL);
        }
        else if (result.error)
        {
            this.error = result.error;
            this.isError = true;
        }
    }
    @wire(getObjectInfo,{objectApiName:Encounter_Obj})
    wiredObjectData(result){
        if(result.data){
            this.allRTInfo = result.data.recordTypeInfos;
            let objName = '';
            if(this.objectApiName.includes('__c')){
                objName = this.objectApiName.replace('__c','');
                if(objName.includes('_')){
                    objName = objName.replace('_',' ');
                }
            }
            else{
                objName = this.objectApiName;
            }
            Object.entries(this.allRTInfo).forEach(item=>{
                if(item[1].name == objName){
                    this.selectedRTId = item[1].recordTypeId;
                }
            })
        }
        else if(result.error){
            console.error(result.error)
        }
    }
    connectedCallback(){
        if(this.objectApiName == 'Referral__c'){
            checkUserAccess({refId: this.recordId})
            .then(result=>{
                console.log('#### ref access: ' + JSON.stringify(result));
                this.hasAccess = result.HasEditAccess;
                console.log('#### access: ' + this.hasAccess);
            })
            .catch(error=>{
                console.error(error);
            })
        }
        if(this.objectApiName=='Client_Service__c'){
            this.hasAccess = true;
        }
    }
    handleStartClick(){
        var presentdate = new Date().toISOString();
        this.startDateTime = presentdate;
        this.stopDisabled = false;
    }
    handleStopClick(){
        var presentdate = new Date().toISOString();
        this.stopDateTime = presentdate;
    }
    handleSave(event){
        event.preventDefault(); 
        this.isSaveDisabled = true
        const fields = event.detail.fields;
        console.log(JSON.parse(JSON.stringify(fields)));
        if(fields.Start_Time__c > fields.End_Time__c){
            alert('Start Time can not be greater than End Time')
        }
        else{
            fields[this.objectApiName] = this.recordId;
            fields.recordTypeId = this.selectedRTId;
            console.log(JSON.parse(JSON.stringify(fields)));
            this.template.querySelector('lightning-record-edit-form').submit(fields);
        }
    }
    enableStop(event){
        var inpVal = event.detail.value;
        if(inpVal != undefined && inpVal != ''){
            this.stopDisabled = false;
        }
        else{
            this.stopDisabled = true;
        }
    }
    handleClear(event){
        this.template.querySelectorAll('lightning-input-field').forEach(each => {
            each.value = null;
        });
        this.stopDisabled = true;
        this.renderCmp = false;
        setTimeout(() => {this.renderCmp = true}, 0);
    }
    handleSuccess(event){
        console.log(event.detail);
        let interactionId=event.detail.id;
        this.isSaveDisabled = false
        this.template.querySelectorAll('lightning-input-field').forEach(item=>{
            item.value = null;
        })
        const toastEvent = new ShowToastEvent({
            title: 'Success !!',
            message: 'Interaction recorded successfully',
            variant:'success'
        });
        this.dispatchEvent(toastEvent);
        if(this.userProfile==='Provider Users'||this.userProfile==='Internal Portal Users')
        {
            //console.log(this.pURL+"detail/"+interactionId);
            window.location.replace(this.pURL+"/detail/"+interactionId);
        }else{
            window.location.replace("/"+interactionId);
        }
    }
    handleError(event){
        console.log('Inside handle error');
        console.log(event);
        console.log(JSON.parse(JSON.stringify(event.detail)));
    }
}



/*@wire(checkUserAccess, { refId: '$recordId'})
wiredUserDetails (result) {
    if (result.data)
    {
        console.log('#### ref access: ' + JSON.stringify(result.data));
        this.hasAccess = result.data.HasEditAccess;
        console.log('#### access: ' + this.hasAccess);
    }
    else if (result.error)
    {
        this.error = result.error;
        console.log('#### error: ' + JSON.stringify(result.error));
    }
}*/