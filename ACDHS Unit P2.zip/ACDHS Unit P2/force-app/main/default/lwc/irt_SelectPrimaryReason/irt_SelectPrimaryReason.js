import { LightningElement, api, wire, track } from 'lwc';
import getPrimaryReasons from '@salesforce/apex/IRT_LWC_Cntrl.getPrimaryReasons';

export default class Irt_SelectPrimaryReason extends LightningElement {
    error;
    @api showQuestionnaire = false; @api conId; @api refType;
    selectPrimReason = true;
    disableNext = true; isLoading = true;
    @track primReasonList = [];
    seletedPrimReasonId; selectedPrimReasonName;

    @wire(getPrimaryReasons, {conId: '$conId', refType: '$refType'})
    wiredPrimReason (result) {
        if (result.data)
        {
            console.log('#### getPrimaryReasons data: ' + JSON.stringify(result.data));
            for (var i = 0; i < result.data.length; i++)
            {
                this.primReasonList = [...this.primReasonList, {value: result.data[i].ServiceId, label: result.data[i].Name, description: result.data[i].Description}];
            }
            var noneReason = {value: 'NoneID', label: 'None', description: 'None of the Above.'};
            this.primReasonList.push(noneReason);
            console.log('#### primReasonList: ' + JSON.stringify(this.primReasonList));
        }
        else if (result.error)
        {
            this.error = result.error;
            console.log('#### getPrimaryReasons error: ' + JSON.stringify(result.error));
        }
        this.isLoading = false;
    }

    handleBack () {
        const backToRefForm = new CustomEvent('backtorefform');
        this.dispatchEvent(backToRefForm);
    }
    
    handleClick (event) {
        let allBoxes = this.template.querySelectorAll('[data-class="prBox"]');
        this.seletedPrimReasonId = event.target.dataset.id;
        console.log('#### tid: ' + this.seletedPrimReasonId);
        this.selectedPrimReasonName = event.target.dataset.name;
        console.log('#### tN: ' + this.selectedPrimReasonName);
        allBoxes.forEach(box => {
            if (box.classList.contains("selected"))
            {
                box.classList.remove("selected");
            }
            if (box.getAttribute("data-id") === this.seletedPrimReasonId)
            {
                box.classList.add("selected");
            }
        });
        this.disableNext = false;
    }

    handleNext () {
        if (this.showQuestionnaire) {}
        else
        {
            this.handlePrimReasonComplete();
        }
    }

    handlePrimReasonComplete () {
        let primReasonDataObj = {primReasonId: this.seletedPrimReasonId, primReasonName: this.selectedPrimReasonName};
        const primReasonSelected = new CustomEvent('submitsuccess', {detail : primReasonDataObj});
        this.dispatchEvent(primReasonSelected);
    }
}