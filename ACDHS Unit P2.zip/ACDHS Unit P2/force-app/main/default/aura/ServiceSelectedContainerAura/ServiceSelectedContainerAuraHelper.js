({
    checkReferralStatus : function(component, event, helper) {
        var action = component.get("c.getReferralStatus");
        action.setParams({  referralId : component.get("v.recordId")});
        action.setCallback(this, function(a){
            var state = a.getState();
            if(state==='SUCCESS')
            {
                var resp = a.getReturnValue();
                if(resp !== 'Accepted')
                {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error",
                        "message": "Referral should be in Accepted Status for service selection.",
                        "type": "error"
                    });
                    toastEvent.fire();
                    $A.get("e.force:closeQuickAction").fire();
                }
            }
            else
            {
                console.debug('Some error occured');
            }
            
        });
        $A.enqueueAction(action);
    }
})