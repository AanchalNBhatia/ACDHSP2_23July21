({
    closeLWC : function(component, event, helper) {
		console.log('aura broker firing..... ');
		$A.get('e.force:refreshView').fire();
		$A.get("e.force:closeQuickAction").fire();
	},
})