declare module "@salesforce/contentAssetUrl/Icon_Conditional_Formatting_png" {
    var Icon_Conditional_Formatting_png: string;
    export default Icon_Conditional_Formatting_png;
}