declare module "@salesforce/contentAssetUrl/iconlearnmorepng" {
    var iconlearnmorepng: string;
    export default iconlearnmorepng;
}