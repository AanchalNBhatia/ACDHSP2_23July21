declare module "@salesforce/label/c.ACDHS" {
    var ACDHS: string;
    export default ACDHS;
}
declare module "@salesforce/label/c.Allegheny_MCI_UserInfo" {
    var Allegheny_MCI_UserInfo: string;
    export default Allegheny_MCI_UserInfo;
}
declare module "@salesforce/label/c.Delete_Record_Owner" {
    var Delete_Record_Owner: string;
    export default Delete_Record_Owner;
}
declare module "@salesforce/label/c.MCI_New_Client_Min_Score" {
    var MCI_New_Client_Min_Score: string;
    export default MCI_New_Client_Min_Score;
}
declare module "@salesforce/label/c.Portal_URL" {
    var Portal_URL: string;
    export default Portal_URL;
}