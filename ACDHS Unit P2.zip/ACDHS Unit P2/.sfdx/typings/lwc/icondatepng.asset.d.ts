declare module "@salesforce/contentAssetUrl/icondatepng" {
    var icondatepng: string;
    export default icondatepng;
}