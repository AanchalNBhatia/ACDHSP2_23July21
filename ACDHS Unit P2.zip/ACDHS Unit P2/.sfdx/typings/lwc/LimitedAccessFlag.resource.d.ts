declare module "@salesforce/resourceUrl/LimitedAccessFlag" {
    var LimitedAccessFlag: string;
    export default LimitedAccessFlag;
}