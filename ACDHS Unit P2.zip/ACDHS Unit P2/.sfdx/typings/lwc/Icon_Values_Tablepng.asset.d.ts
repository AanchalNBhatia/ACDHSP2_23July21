declare module "@salesforce/contentAssetUrl/Icon_Values_Tablepng" {
    var Icon_Values_Tablepng: string;
    export default Icon_Values_Tablepng;
}