declare module "@salesforce/contentAssetUrl/iconcomparepng" {
    var iconcomparepng: string;
    export default iconcomparepng;
}