declare module "@salesforce/contentAssetUrl/arrowlpng" {
    var arrowlpng: string;
    export default arrowlpng;
}