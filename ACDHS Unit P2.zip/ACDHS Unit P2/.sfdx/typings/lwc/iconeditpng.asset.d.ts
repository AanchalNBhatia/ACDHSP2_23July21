declare module "@salesforce/contentAssetUrl/iconeditpng" {
    var iconeditpng: string;
    export default iconeditpng;
}