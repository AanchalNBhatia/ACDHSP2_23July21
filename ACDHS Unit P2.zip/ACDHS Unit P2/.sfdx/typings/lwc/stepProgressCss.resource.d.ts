declare module "@salesforce/resourceUrl/stepProgressCss" {
    var stepProgressCss: string;
    export default stepProgressCss;
}