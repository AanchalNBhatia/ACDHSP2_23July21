declare module "@salesforce/contentAssetUrl/iconchartpng" {
    var iconchartpng: string;
    export default iconchartpng;
}