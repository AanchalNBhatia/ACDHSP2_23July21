declare module "@salesforce/contentAssetUrl/arrowrpng" {
    var arrowrpng: string;
    export default arrowrpng;
}