declare module "@salesforce/contentAssetUrl/Icon_Time_Seriespng" {
    var Icon_Time_Seriespng: string;
    export default Icon_Time_Seriespng;
}