declare module "@salesforce/contentAssetUrl/icongrouppng" {
    var icongrouppng: string;
    export default icongrouppng;
}