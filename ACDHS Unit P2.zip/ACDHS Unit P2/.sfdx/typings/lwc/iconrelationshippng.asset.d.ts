declare module "@salesforce/contentAssetUrl/iconrelationshippng" {
    var iconrelationshippng: string;
    export default iconrelationshippng;
}