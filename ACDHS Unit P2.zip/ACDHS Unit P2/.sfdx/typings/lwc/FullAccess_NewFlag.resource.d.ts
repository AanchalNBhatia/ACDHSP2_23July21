declare module "@salesforce/resourceUrl/FullAccess_NewFlag" {
    var FullAccess_NewFlag: string;
    export default FullAccess_NewFlag;
}