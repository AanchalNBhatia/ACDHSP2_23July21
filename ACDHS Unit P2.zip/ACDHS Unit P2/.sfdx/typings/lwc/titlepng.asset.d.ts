declare module "@salesforce/contentAssetUrl/titlepng" {
    var titlepng: string;
    export default titlepng;
}