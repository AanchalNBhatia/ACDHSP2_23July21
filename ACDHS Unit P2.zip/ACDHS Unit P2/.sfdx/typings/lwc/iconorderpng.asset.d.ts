declare module "@salesforce/contentAssetUrl/iconorderpng" {
    var iconorderpng: string;
    export default iconorderpng;
}