declare module "@salesforce/contentAssetUrl/iconsequencespng" {
    var iconsequencespng: string;
    export default iconsequencespng;
}