declare module "@salesforce/resourceUrl/Allegheny_Long_Logo" {
    var Allegheny_Long_Logo: string;
    export default Allegheny_Long_Logo;
}