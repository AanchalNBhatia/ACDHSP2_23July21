declare module "@salesforce/contentAssetUrl/Icon_Pivot_Tablepng" {
    var Icon_Pivot_Tablepng: string;
    export default Icon_Pivot_Tablepng;
}