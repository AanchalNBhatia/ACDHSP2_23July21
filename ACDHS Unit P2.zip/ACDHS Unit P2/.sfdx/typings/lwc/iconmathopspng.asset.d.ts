declare module "@salesforce/contentAssetUrl/iconmathopspng" {
    var iconmathopspng: string;
    export default iconmathopspng;
}