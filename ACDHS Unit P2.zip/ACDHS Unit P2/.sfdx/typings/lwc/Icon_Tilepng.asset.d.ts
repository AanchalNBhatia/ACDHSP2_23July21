declare module "@salesforce/contentAssetUrl/Icon_Tilepng" {
    var Icon_Tilepng: string;
    export default Icon_Tilepng;
}