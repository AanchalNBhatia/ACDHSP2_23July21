declare module "@salesforce/contentAssetUrl/astro_clipboardpng" {
    var astro_clipboardpng: string;
    export default astro_clipboardpng;
}