declare module "@salesforce/contentAssetUrl/iconcodepng" {
    var iconcodepng: string;
    export default iconcodepng;
}