declare module "@salesforce/contentAssetUrl/Icon_Formulaspng" {
    var Icon_Formulaspng: string;
    export default Icon_Formulaspng;
}