declare module "@salesforce/contentAssetUrl/Sectionhead1png" {
    var Sectionhead1png: string;
    export default Sectionhead1png;
}