declare module "@salesforce/contentAssetUrl/icontablepng" {
    var icontablepng: string;
    export default icontablepng;
}