declare module "@salesforce/contentAssetUrl/iconmetricspng" {
    var iconmetricspng: string;
    export default iconmetricspng;
}