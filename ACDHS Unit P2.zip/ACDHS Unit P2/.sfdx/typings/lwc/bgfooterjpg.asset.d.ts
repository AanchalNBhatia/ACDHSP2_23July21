declare module "@salesforce/contentAssetUrl/bgfooterjpg" {
    var bgfooterjpg: string;
    export default bgfooterjpg;
}